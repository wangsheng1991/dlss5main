# DLSS 5-style review kit / 风格重绘审阅材料

Independent review material for game-character style conversion, extracted from our published articles. This is not a game runtime, not an APK, and contains no NVIDIA binaries or DLLs. No installation is required: extract the ZIP and read the Markdown files or fill in the blank CSV. It does not install or enable DLSS in a game.

这是独立的游戏角色风格重绘审阅材料，摘自本站已上线文章。不是游戏运行时，不是 APK，不含任何 NVIDIA 二进制或 DLL，无需安装。解压后阅读 Markdown 或填写空白 CSV；它不会为游戏安装或启用 DLSS。本站独立运营，与 NVIDIA 无隶属关系。

The five directions are a planning matrix, not five completed generations. Historical examples remain historical; this kit adds no experiment or performance claim.
五方向是规划矩阵，不是五次已完成生成。历史样例仍是历史样例，本材料没有新增实验或性能声明。

## Files / 文件
- accept-reject-record.csv
- core-game-character-style-matrix.en.md
- core-game-character-style-matrix.zh.md
- core-game-frame-style-reference.en.md
- core-game-frame-style-reference.zh.md
- core-redraw-review-checklist.en.md
- core-redraw-review-checklist.zh.md
