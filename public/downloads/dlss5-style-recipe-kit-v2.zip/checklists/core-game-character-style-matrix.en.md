# One game character, five style directions: plan a DLSS 5-style comparison matrix

Source: https://www.dlss5nvidia.com/blog/core-game-character-style-matrix

## The five-direction planning matrix

The following rows are suggested briefs. None is presented as a new measured output. The names match directions discussed on the site's character page; the matrix is not an automatic batch feature or a claim that the interface contains these exact preset buttons.

| Direction | Light to investigate | Material treatment to investigate | Palette question | Keep checking |
| --- | --- | --- | --- | --- |
| Cyberpunk | Colored edge light and reflected street light | Relationship between cloth and reflective fittings | Can colored accents stay subordinate to the character? | Exposed hair, costume edges, equipment shape |
| Fantasy | A warm or cool dramatic source with readable shadows | Cloth, leather and metal as distinct surfaces | Does a restrained accent identify the protagonist? | No invented armor or changed silhouette |
| Science fiction | Controlled directional light on existing equipment | A cleaner treatment of the existing surfaces | Can a cooler palette work without erasing costume cues? | No new visor, helmet or mechanical limb |
| Anime | Grouped light and shadow shapes | Simplified surface detail rather than added objects | Do color blocks preserve the costume's organization? | Facial arrangement, hair outline and garment divisions |
| Realistic | More natural-looking light relationships | Plausible surface response on the existing design | Does the scene remain readable with quieter accents? | No replacement face or redesign disguised as realism |

These columns turn style labels into questions. They do not claim that fantasy always uses warm light or science fiction always uses cool colors. You are selecting a particular treatment to compare, not defining every possible example of a genre. Change the proposal when it does not match the game world's art direction.

## When to stop and what to hand over

Stop a direction when it repeatedly conflicts with a protected identity feature, when the source is too ambiguous to judge, or when the next variation has no clear decision to answer. These are recommended stopping conditions, not observed failure frequencies. A team should set its practical attempt limit before spending time or usage allowance.

An acceptable endpoint can be one useful visual direction with specific unresolved details. It need not be five finished winners. Hand over the original, the candidate and a short acceptance explanation so that the next artist knows whether they are reviewing lighting, costume or a complete character concept.

For the preservation criteria, read the existing [character-consistency guide](https://www.dlss5nvidia.com/blog/core-character-consistency-style-conversion). The [game-character style tool](https://www.dlss5nvidia.com/game-character-style) is the corresponding workflow entry. Game character style exploration remains a creative review task, not proof that a manufacturer runtime processed these images.

## Disclosure

We operate the linked site independently and are not affiliated with NVIDIA or Black Forest Labs. The pictures are authorized site-owned historical samples. No fresh five-direction experiment, game integration, temporal test or hardware measurement was performed for this article. The matrix is ready to guide a future comparison, with its untested rows stated plainly.
