# A neural redraw checklist: use style conversion without losing track of what changed

Source: https://www.dlss5nvidia.com/blog/core-redraw-review-checklist

## TL;DR

- Judge the intended visual direction and preservation requirements separately.
- Keep complete sources and outputs, including failed or provisional results.
- Inspect lettering, emblems, recognizable features, and spatial relationships before approval.
- Our recorded room examples support observations about those images, not a universal fidelity claim.

## Small text: compare meaning before appearance

### Inspect characters as characters

A caption, appliance label, sign, or interface control communicates information. In a style redraw it can also become visual texture. The review must therefore ask whether the actual characters survived, not whether the mark looks sufficiently like writing from a normal viewing distance.

In the kitchen pair, the upper interface overlay and appliance labels remain available to inspect. We do not certify the wording of tiny text from the comparison image. Use the supplied full files and the source wording, if known, rather than treating plausible output lettering as a transcript.

If a letter cannot be verified, mark it unresolved. That is different from claiming that it definitely changed. If a clear source character becomes a different character, record the mismatch. A useful checklist distinguishes observed errors from places where the available image cannot support a judgment.

### Keep annotations outside generated pixels

Write the task identifier and review decision in the surrounding document. If you place them inside an image and send that image through another redraw, they become part of the generated scene. The audit trail should remain readable independently of the model's treatment of text.

For a presentation, you can supply a separate caption describing the creative direction. Do not use an invented label in the image as evidence of a product name or a historical fact. A visual reference can still serve its purpose while the editor explicitly excludes its lettering from reuse.

## Logos and symbols: shape alone is insufficient

A logo may remain recognizable while its letter spacing, internal cutouts, or proportions change. The same applies to a fictional emblem that a character designer wants preserved. Check the mark against the authorized source artwork, including the space around it, rather than approving it because the color is familiar.

Our room examples do not provide a verified brand-logo test. We include logo inspection as an acceptance criterion for readers whose own sources contain such marks. We do not invent a successful logo-preservation experiment from an appliance label that cannot be verified here.

A generated symbol also does not establish permission to use it commercially. The relevant practical step is to keep the source and ask the responsible owner or designer to approve the final mark where needed. This is an editorial review recommendation, not a legal determination.

![Recorded kitchen source and redraw with interface text and appliance details visible](assets/kitchen-compare.jpg)

*Figure 2. Existing comparison from the October 21 kitchen task, copied unchanged. Source: site-owned sample1 render and its real flux-klein output; license: own. kitchen-run.json preserves the request. Text, tap, and appliance shapes require review; the result was not approved for direct publication as a faithful scene.*

## Identity: familiarity needs a separate check

A recognizable person or character has more than a broad silhouette. Face shape, hairline, expression, distinctive marks, and costume construction can matter to recognition. A change that seems minor to the editor may be obvious to the person pictured or the character's designer.

These interior examples contain no faces. They cannot establish facial identity preservation, nor can they tell you how a face-oriented tool behaves. For an authorized portrait, compare against the original and seek the subject's review before treating the result as an acceptable representation.

Keep the identity question separate from whether the rendering looks attractive. You can like the light while rejecting a changed expression. For a fictional character, the same logic applies to a helmet, badge, hairstyle, or costume seam that carries the design's identity.

## Exact proportions: a concept is not a measurement

A room can look credible while the apparent size of the bench, the placement of a cabinet seam, or the relation between window and wall changes. A plausible perspective does not prove that furniture fits. If a decision depends on dimensions, retain measured information outside the generated picture.

The bedroom record requests preservation of the arrangement. Its review nevertheless identifies changes in artwork, pillow patterns, cabinet layout, and some spatial proportions. The appropriate conclusion is that the image can inform a lighting discussion while remaining unsuitable as evidence of exact geometry.

Do not convert that observation into a percentage of geometric accuracy. We did not establish a calibrated camera, measured reference scene, or numerical registration experiment. The record supports a visual comparison and named concerns, which are sufficient to decide that a stricter geometry claim has not been demonstrated.

## Write a decision someone else can use

A review note should name the intended visual change, the region checked, what was observed, and the permitted use. For the bedroom, a reader can discuss material response while retaining a concern about decorative and geometric differences. A generic approved stamp would discard that useful distinction.

For text, use separate outcomes such as verified against source, mismatch observed, and not readable enough to verify. For identity, distinguish a subject-approved result from an editor's impression. For proportions, distinguish a visual plausibility check from a measurement. These labels describe the evidence rather than pretending every task has the same threshold.

The neural redraw checklist is intended to keep useful creative work moving. A result that fails one requirement may still be an honest reference for another purpose, provided the recipient can see the limitation. Reclassifying the use is acceptable; hiding the failure is not a substitute for review.

## Technical context and limits

BFL's [image-editing guide](https://docs.bfl.ml/flux_2/flux2_image_editing) describes prompt-based edits, and its [multi-reference overview](https://help.bfl.ai/articles/6546682167-what-is-multi-reference-editing) explains combining reference content. Those pages give background, not independent validation of these recorded outputs. No images from either source appear here.

Use this neural redraw checklist before calling an output a finished reference. It cannot guarantee unchanged words, logos, identity, proportions, commercial suitability, or temporal stability. This article concerns independent static style conversion, not NVIDIA runtime output. We operate the linked site and are not affiliated with NVIDIA, AMD, or Black Forest Labs. The original files remain the basis for every review.
