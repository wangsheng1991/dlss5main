# DLSS 5-style recipe kit v2 / 风格重绘配方包 v2

Own fixed sample prompts, unchanged bilingual review excerpts, an unverified planning template, a blank record and a local metadata viewer. No model is called. / 包含自有固定样例提示词、原样双语审阅段、未验证模板、空白记录与本地元数据查看脚本，不调用模型。

## Usage / 用法

Extract the ZIP. Read prompts/catalog.json for source and output relationships. The room/kitchen article records are different tasks, not evidence for the fixed sample prompts. / 解压后先读提示词目录中的对应关系，室内文章记录不能当作固定样例提示词的效果证据。

With Node.js 18 or later, put your two images beside tools/review-pair.mjs and run from that folder: / 安装 Node.js 18 或更新版，把自己的两张图放在 tools/review-pair.mjs 旁，在该目录运行：

```sh
node review-pair.mjs source.jpg result.webp
```

The zero-dependency script creates a fresh review-pair-* directory with index.html, pair.json and unchanged local image copies. Open index.html for a side-by-side view. It reports encoded JPEG/PNG/WebP dimensions, bytes, SHA-256 and actual generation time; EXIF rotation is not applied. Fill decision and acceptRejectReason yourself. No quality score or similarity conclusion is produced. / 零依赖脚本生成新的 review-pair-* 目录，含并排网页、pair.json 与原样图片副本。只测编码像素尺寸、字节数、哈希与实际生成时间，不应用 EXIF 旋转；接受或拒收理由由你填写，不给画质或相似度结论。图片不上传。

## Boundaries and permission / 边界与许可

These materials are our own content and may be freely used for your own project reviews. This permission does not license third-party material. Independent of NVIDIA: not a game runtime, not an APK, no NVIDIA binaries or DLLs. No installation into a game is required or performed. Historical examples remain historical; templates have unverified effects. / 材料为我们自有内容，可自由用于自己的项目评审；许可不涵盖第三方材料。本站与 NVIDIA 无隶属关系。本包不是运行时、不是 APK，不含任何 NVIDIA 二进制或 DLL，不需要也不会向游戏安装内容。历史样例仍是历史样例，模板未验证效果。
