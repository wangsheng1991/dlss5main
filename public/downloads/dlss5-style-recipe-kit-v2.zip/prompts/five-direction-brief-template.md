# Five-direction brief template / 五方向简报模板

Template, effects not verified. / 模板，未验证效果。
Source: https://www.dlss5nvidia.com/blog/core-game-character-style-matrix
中文：https://www.dlss5nvidia.com/zh/blog/core-game-character-style-matrix
Read the unchanged bilingual planning matrix in checklists/ before filling this form. These are review briefs, not completed generations or tested prompts. / 先读 checklists/ 中原样收录的双语规划矩阵。这里是审阅简报，不是已完成生成或经过效果验证的提示词。

## Cyberpunk / 赛博朋克

- Source image / 源图：
- Protected identity, costume and camera / 保留身份、服装、镜头：
- Intended light / 光照目标：
- Intended material / 材质目标：
- Intended palette / 配色目标：
- Reject if / 拒收条件：
- Review notes / 审阅记录：

## Fantasy / 奇幻

- Source image / 源图：
- Protected identity, costume and camera / 保留身份、服装、镜头：
- Intended light / 光照目标：
- Intended material / 材质目标：
- Intended palette / 配色目标：
- Reject if / 拒收条件：
- Review notes / 审阅记录：

## Science fiction / 科幻

- Source image / 源图：
- Protected identity, costume and camera / 保留身份、服装、镜头：
- Intended light / 光照目标：
- Intended material / 材质目标：
- Intended palette / 配色目标：
- Reject if / 拒收条件：
- Review notes / 审阅记录：

## Anime / 动漫

- Source image / 源图：
- Protected identity, costume and camera / 保留身份、服装、镜头：
- Intended light / 光照目标：
- Intended material / 材质目标：
- Intended palette / 配色目标：
- Reject if / 拒收条件：
- Review notes / 审阅记录：

## Realistic / 写实

- Source image / 源图：
- Protected identity, costume and camera / 保留身份、服装、镜头：
- Intended light / 光照目标：
- Intended material / 材质目标：
- Intended palette / 配色目标：
- Reject if / 拒收条件：
- Review notes / 审阅记录：
