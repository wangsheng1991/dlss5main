# Fixed public style-sample prompts / 公开风格样例固定提示词

The .txt files are exact prompt strings from src/config/samples.ts, used by the public image-edit sample path. catalog.json identifies each source, cached output URL and related published discussion. The output endpoint can change as the site cache is refreshed; this package does not run a model or guarantee reproduction.

.txt 逐字导出样例定义中的提示词；catalog.json 标注输入、缓存输出地址和文章关系。characterStyle 的文章讨论对应固定提示词样例。sample1、sample2 的审阅文章使用相同源图，但讨论的是另一组历史任务，提示词不同，不能把文章配图归因于这两条固定提示词。缓存地址可能随样例更新而变化，本包没有新跑模型，也不保证复现效果。

Only the three image style-conversion samples are included. Tool-catalog labels for cutout, erasing and vectorization are not presented as verified style recipes. / 仅收录三条图像风格转换样例；去背景、抹除、矢量化的工具说明不冒充风格配方。
